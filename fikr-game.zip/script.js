
console.log("تم تحميل اللعبة!");
